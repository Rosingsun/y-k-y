export { default as PageConfig } from './PrivateRoute/index';//路由

export { default as Search } from './common/search/index';//路由

export {default as PopUp }from './common/PopUp/index';
