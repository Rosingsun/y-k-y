export const ADD_TEST = 'ADD_TEST';//测试，一个事例

export const GET_USER_INFO = 'GET_USER_INFO';//基本上两个内容一样