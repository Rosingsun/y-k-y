export { default as Home } from './Home/index.jsx';//主页

export { default as Login } from './Login/index.jsx';//登录注册

export { default as Data } from './Data/index.jsx';//介绍

export {default as userList} from './userList/index.jsx';//用户列表